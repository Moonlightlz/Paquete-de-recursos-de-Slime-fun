# Créditos y procedencia

La base es **Slimefun Legacy Resource Pack 4.0.2**, publicado por wickidcow:
https://github.com/wickidcow/SFL_RP_Official/releases/tag/v4.0.2

Se conserva el paquete combinado completo, su `Credits` en `pack.mcmeta` y su
`README_MERGE.txt`. Los modelos y texturas pertenecen a sus autores originales.
La licencia del proyecto de integración original se incluye como `LICENSE`
(GPL-3.0); los créditos originales de los recursos siguen siendo aplicables.

La integración de RainxEnma añade correspondencias de IDs de los addons instalados,
cinco adaptaciones de materiales portadores y una descripción del paquete en español.
No presenta las texturas originales como propias. Las herramientas y adaptaciones
de este repositorio se distribuyen bajo GPL-3.0-o-posterior.

Referencia de modelos: `item-models.yml` de Slimefun Legacy, revisión `f68544e`.
Los hashes de las fuentes y el detalle de cobertura están en `sources.json`.

Autores acreditados en la base: Raulh22, Den4enko, LoneDev, Caribax, ybw0014,
DragonMysterious, AnsonYK, Sofia Redmond, Jerry, haiman, RelativoBR,
Filosofas154, JustAHuman-xD y Pandicka. Se conservan sus enlaces originales.

## Selección de Eternals

El propietario del servidor proporcionó `eternals.zip` para sustituir las secciones
Resources, Useful Items, Technical Components, Miscellaneous Items, Magical
Gadgets y el equipo de Infinity. El paquete de origen acredita a luxbx y
https://store.eternals.top; los modelos seleccionados conservan también sus campos
`author` originales, principalmente RaulH22 y Caribax.

Solo se incorporan los archivos necesarios para esos objetos. Las imágenes y sus
animaciones se copian sin alterarlas; los modelos se adaptan al formato actual y
se aíslan en el espacio `rainxenma_eternals`. Los derechos de esos recursos siguen
siendo de sus autores; la licencia GPL de las herramientas de integración no
relicencia las texturas proporcionadas. Los hashes y la correspondencia exacta de
objetos están en `server/eternals-selection.json`.

## EliteMobs

Iconos, modelos, texturas y fondos del paquete oficial de EliteMobs de MagmaGuy:
https://magmaguy.com/downloads/elitemobs_resource_pack.zip .
Se conservan sus recursos y campos de autor; las adaptaciones de rutas de
Minecraft 26.2 no alteran la titularidad de esos recursos.

## Música

`assets/rainxenma_music/sounds/boss/lost_within.ogg` (evento de sonido
`rainxenma_music:boss.lost_within`, música de la fase 4 del Vinculador de Mundos):

- «Lost Within», de **A Himitsu**, publicada por **Argofox**.
- Licencia: Creative Commons Attribution (CC BY), según la publicación de Argofox:
  https://soundcloud.com/argofox/a-himitsu-lost-within
  y la copia del Internet Archive: https://archive.org/details/soundcloud-184035090
- Original del artista: https://youtu.be/e6YS10l_NFY

Cambios: versión editada por el servidor RainxEnma. Se recortó (sin la intro larga,
unos 2:15 de duración) y se ajustó la ecualización de graves y agudos. Después se
convirtió a Ogg Vorbis estéreo de 44,1 kHz y se normalizó el volumen (loudnorm, −16 LUFS).
La música no se incluye en el paquete ligero de `/optimizacion`.
